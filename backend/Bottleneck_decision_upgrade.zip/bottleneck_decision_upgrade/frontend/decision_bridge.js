
/*
 * BOTTLENECK decision bridge.
 * Add this script to logo.html after the existing scripts.
 * It does not replace the visual simulation; it makes the business decision
 * simulator authoritative by sending inputs to the FastAPI backend.
 */
window.BOTTLENECK_API = window.BOTTLENECK_API || "http://localhost:8000";

async function bottleneckDecisionAnalyze(problem) {
  const res = await fetch(`${window.BOTTLENECK_API}/decision/analyze`, {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({problem})
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

async function bottleneckDecisionSimulate(inputs, assumptions = {}) {
  const res = await fetch(`${window.BOTTLENECK_API}/decision/simulate`, {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({inputs, assumptions})
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

async function bottleneckDecisionWhatIf(inputs, changes, assumptions = {}) {
  const res = await fetch(`${window.BOTTLENECK_API}/decision/what-if`, {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({inputs, changes, assumptions})
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

async function bottleneckDecisionStress(inputs, assumptions = {}, shocks = {}) {
  const res = await fetch(`${window.BOTTLENECK_API}/decision/stress-test`, {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({inputs, assumptions, shocks})
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

# BOTTLENECK Business Decision Simulator Upgrade

## Additions

- `backend/app/decision.py` — deterministic business-expansion/investment model.
- `frontend/decision_bridge.js` — browser integration helpers.
- `backend/app/main.py` — four new decision endpoints.

## Endpoints

- `POST /decision/analyze`
- `POST /decision/simulate`
- `POST /decision/what-if`
- `POST /decision/stress-test`

No LLM is required for the deterministic core. `/decision/analyze` only extracts facts from the user's text; numerical outcomes are calculated by `decision.py`.

## Example

```json
POST /decision/analyze
{"problem":"I have ₹5 crore and I'm thinking about opening a new branch in Hyderabad."}
```

The response deliberately reports missing financial inputs rather than inventing them.

Then submit a complete model:

```json
POST /decision/simulate
{
  "inputs": {
    "capital_available": 50000000,
    "investment_required": 20000000,
    "monthly_revenue": 5000000,
    "monthly_operating_cost": 3000000,
    "gross_margin_pct": 45,
    "monthly_growth_pct": 2,
    "working_capital_months": 6,
    "horizon_months": 36,
    "risk_tolerance": "medium",
    "location": "Hyderabad"
  }
}
```

The response contains conservative/base/aggressive scenarios, profit, ROI, payback, capital coverage, risk and a deterministic recommendation.

## Frontend

Add:

```html
<script src="./decision_bridge.js"></script>
```

before the closing `</body>` tag of `logo.html`.

The existing visual sliders can remain; this bridge is the API layer for the business decision simulator.
